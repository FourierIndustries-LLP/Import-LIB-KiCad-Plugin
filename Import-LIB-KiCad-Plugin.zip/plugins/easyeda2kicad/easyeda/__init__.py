"""
EasyEDA module - Handle EasyEDA data import and processing
"""

# Local imports
from .easyeda_api import EasyedaApi
from .easyeda_importer import (
    Easyeda3dModelImporter,
    EasyedaFootprintImporter,
    EasyedaSymbolImporter,
)
from .parameters_easyeda import (
    EasyedaPinType,
    Ee3dModel,
    EeSymbol,
    EeSymbolArc,
    EeSymbolCircle,
    EeSymbolInfo,
    EeSymbolPath,
    EeSymbolPin,
    EeSymbolPolygon,
    EeSymbolPolyline,
    EeSymbolRectangle,
    EeFootprint,
)

__all__ = [
    # API
    "EasyedaApi",
    # Importers
    "EasyedaSymbolImporter",
    "EasyedaFootprintImporter",
    "Easyeda3dModelImporter",
    # Data structures
    "EasyedaPinType",
    "EeSymbol",
    "EeSymbolInfo",
    "EeSymbolPin",
    "EeSymbolRectangle",
    "EeSymbolCircle",
    "EeSymbolArc",
    "EeSymbolPolyline",
    "EeSymbolPolygon",
    "EeSymbolPath",
    "EeFootprint",
    "Ee3dModel",
]
